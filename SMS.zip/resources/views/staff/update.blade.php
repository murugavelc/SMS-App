@extends('app')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="pull-right">
                    <a class="btn btn-primary" href="{{ URL::to('/staff') }}"> Back</a>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Update Staff Details</div>
                    <div class="panel-body">
                        @if (count($errors) > 0)
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <form class="form-horizontal" role="form" method="POST" action="{{ URL::to('/staff/update') }}">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            <input type="hidden" name="user_id" value="{{ $staffs->user_id }}">

                            <div class="form-group">
                                <label class="col-md-4 control-label">Name</label>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="name" value="{{ $staffs->name }}">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-4 control-label">Employee Id</label>
                                <div class="col-md-6">
                                    <input type="number" class="form-control" name="emp_id" value="{{ $staffs->emp_id }}">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-4 control-label">E-Mail Address</label>
                                <div class="col-md-6">
                                    <input type="email" class="form-control" name="email" value="{{ $staffs->email }}">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-4 control-label">Phone</label>
                                <div class="col-md-6">
                                    <input type="number" class="form-control" name="phone" value="{{ $staffs->phone }}">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-4 control-label">Degree</label>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="degree" value="{{ $staffs->degree }}">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-4 control-label">Department</label>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="department" value="{{ $staffs->department }}">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-4 control-label">Date of Join</label>
                                <div class="col-md-6">
                                    <input type="date" class="form-control" name="doj" value="{{ $staffs->date_of_join }}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-4 control-label">Profile</label>
                                <div class="col-md-6">
                                    <div class="col-md-6 col-md-offset-3">
                                        <img src="{{URL::to('images/profile/staffs/'. $staffs->profile)}}" height="120px" width="120px" \>
                                    </div>
                                    <input type="file" class="form-control" name="photo" id ="photo">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                       Update
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
