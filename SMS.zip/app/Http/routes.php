<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', function()
{
    return View::make('login');
});

Route::group(['prefix'=> 'staff',  'middleware' => 'App\Http\Middleware\AdminMiddleware'], function (){
    Route::get('/', 'StaffController@index');
    Route::get('/create', 'StaffController@create');
    Route::post('/create', 'StaffController@create');
    Route::get('/store', 'StaffController@store');
    Route::post('/store', 'StaffController@store');
    Route::get('/show/{id}', 'StaffController@show');
    Route::post('/show/{id}', 'StaffController@show');
    Route::get('/edit/{id}', 'StaffController@edit');
    Route::post('/edit/{id}', 'StaffController@edit');
    Route::get('/update', 'StaffController@update');
    Route::post('/update', 'StaffController@update');
    Route::get('/delete/{id}', 'StaffController@destroy');
    Route::post('/delete/{id}', 'StaffController@destroy');
    Route::get('/photo/{filename}', 'StaffController@getStaffPhoto');
    Route::get('/mail', 'StaffController@sendEmail');
});
Route::group(['prefix'=> 'student',  'middleware' => 'App\Http\Middleware\AdminMiddleware'], function (){
    Route::get('/', 'StudentController@index');
    Route::get('/create', 'StudentController@create');
    Route::post('/create', 'StudentController@create');
    Route::get('/store', 'StudentController@store');
    Route::post('/store', 'StudentController@store');
    Route::get('/show/{id}', 'StudentController@show');
    Route::post('/show/{id}', 'StudentController@show');
    Route::get('/edit/{id}', 'StudentController@edit');
    Route::post('/edit/{id}', 'StudentController@edit');
    Route::get('/update', 'StudentController@update');
    Route::post('/update', 'StudentController@update');
    Route::get('/delete/{id}', 'StudentController@destroy');
    Route::post('/delete/{id}', 'StudentController@destroy');

});
Route::group(['prefix'=> 'admin', 'middleware' => 'App\Http\Middleware\AdminMiddleware'], function (){
    Route::get('/', 'AdminController@index');

});
Route::group(['prefix'=> 'admin' ], function (){
    Route::post('/authenticate','LoginController@Webauthenticate');
});

// Login, Register and Logout
//    Route::get('/login', 'Auth\AuthController@getLogin');
//    Route::post('/login', 'Auth\AuthController@postLogin');
    Route::post('/login','LoginController@Webauthenticate');
    Route::get('/logout', 'Auth\AuthController@getLogout');

Route::group(['prefix'=> '/v1.0/api'], function (){
    Route::get('/login','LoginController@Apiauthenticate');
    Route::post('/login','LoginController@Apiauthenticate');
    Route::get('/staff', 'StaffController@ApiAllStaff');
    Route::get('/create', 'StaffController@Apistore');
    Route::post('/create', 'StaffController@Apistore');
    Route::get('/show/{id}', 'StaffController@Apishow');
    Route::post('/show/{id}', 'StaffController@Apishow');
    Route::get('/edit/{id}', 'StaffController@Apiedit');
    Route::post('/edit/{id}', 'StaffController@Apiedit');
    Route::get('/update/{id}', 'StaffController@Apiupdate');
    Route::post('/update/{id}', 'StaffController@Apiupdate');
    Route::get('/delete/{id}', 'StaffController@Apidestroy');
    Route::post('/delete/{id}', 'StaffController@Apidestroy');

});
